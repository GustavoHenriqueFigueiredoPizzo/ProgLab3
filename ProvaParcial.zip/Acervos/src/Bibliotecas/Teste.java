
package Bibliotecas;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Teste {
    
    public static void main(String[] args) {
        
        List<Usuário> usuarios = new ArrayList<>();
        List<Livro> livro = new ArrayList<>();      
        List<Empréstimos> emprestimos = new ArrayList<>();     
        
        
        usuarios.add(new Usuário(831382,"Gustavo","gustavohpizzo@gamil.com","10203040"));
        usuarios.add(new Usuário(811608,"Douglas","DouglasdaSilva@hotmail.com","90807060"));
        usuarios.add(new Usuário(824586,"Caio","CaioCosta@gamil.com","1050100"));
        usuarios.add(new Usuário(815488,"Afonso","AfonsoGomes@gamil.com","684215973"));
        usuarios.add(new Usuário(836974,"lucas","LucasSantos@gamil.com","36521485"));
        
        livro.add(new Livro (001,"Eles não são anjos como eu","Marcia Kupstas","1º","Moderna","São Paulo",2007));
        livro.add(new Livro (002,"Os detetives do farol","Klaus Bliesener","4º","Editora Ática","São Paulo",2004));
        livro.add(new Livro (003,"Leite Derramado","Chico Buarque","1º","Companhia das Letrasd","São Paulo",2011));
        livro.add(new Livro (004,"A terra vista do alto","Fernando Carraro","1º","Editora FTD S.A.","São Paulo",2000));        
        livro.add(new Livro (005,"A maldição do silêncio","Marcia Kupstas","2º","Moderna","São Paulo",2003));
        
        emprestimos.add(new Empréstimos(1001,831382,003,LocalDate.of(2020, Month.MARCH, 12),LocalDate.now(),"Sim"));
        emprestimos.add(new Empréstimos(1002,811608,001,LocalDate.of(2020, Month.JANUARY, 03),LocalDate.now(),"Sim"));
        emprestimos.add(new Empréstimos(1003,824586,004,LocalDate.of(2020, Month.AUGUST, 22),LocalDate.now(),"Não"));
        emprestimos.add(new Empréstimos(1004,815488,005,LocalDate.of(2020, Month.NOVEMBER, 26),LocalDate.now(),"Sim"));
        emprestimos.add(new Empréstimos(1005,836974,002,LocalDate.of(2020, Month.SEPTEMBER, 18),LocalDate.now(),"Não"));
        
        usuarios.forEach((c) -> {
            System.out.println(c);
        });
        
        livro.forEach((c) -> {
            System.out.println(c);
        });
        
        emprestimos.forEach((c) -> {
            System.out.println(c);
        });
    }
}
   
