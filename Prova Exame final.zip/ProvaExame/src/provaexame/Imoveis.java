/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provaexame;

import java.util.ArrayList;
import java.util.List;

public class Imoveis {
    

    private String aaa;
    private String bbb;
    private String ccc;
    private String ddd;
    private String eee;

    public Imoveis() {
    }

    public Imoveis(String aaa, String bbb, String ccc, String ddd, String eee) {
        this.aaa = aaa;
        this.bbb = bbb;
        this.ccc = ccc;
        this.ddd = ddd;
        this.eee = eee;
    }

    
    public String getNome() {
        return aaa;
    }

    public void setNome(String aaa) {
        this.aaa = aaa;
    }

    public String gettipo() {
        return bbb;
    }

    public void settipo(String bbb) {
        this.bbb = bbb;
    }

    public String getdescricao() {
        return ccc;
    }

    public void setDescricao(String ccc) {
        this.ccc = ccc;
    }

    public String getCategoria() {
        return ddd;
    }

    public void setCategoria(String ddd) {
        this.ddd = ddd;
    }

    public String getValorvenda() {
        return eee;
    }

    public void setValorvenda(String eee) {
        this.eee = eee;
    }

    public List<String> getDados() {
        return dados;
    }

    public void setImovel(List<String> dados) {
        this.dados = dados;
    }
    List<String>dados = new ArrayList<>();
    
}
